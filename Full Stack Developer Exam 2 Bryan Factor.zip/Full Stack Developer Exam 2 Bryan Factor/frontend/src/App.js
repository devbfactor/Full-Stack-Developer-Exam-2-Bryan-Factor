import './App.css';
import Body from './component/Body';

function App() {
  return (
    <div>
      <Body />
    </div>
  );
}

export default App;
