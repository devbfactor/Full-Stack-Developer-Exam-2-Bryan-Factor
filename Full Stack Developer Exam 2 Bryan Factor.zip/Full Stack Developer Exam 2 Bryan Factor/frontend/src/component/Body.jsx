import React, { useEffect, useState } from 'react';

const Body = () => {
    const [details, setDetails] = useState([]);
    const [searchPhrase, setSearchPhrase] = useState("")
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        setLoading(true)
        async function getData() {
            const res = await fetch('https://api.spacexdata.com/v5/launches/', {
                method: 'GET',
                headers: {
                    accept: 'application/json',
                },
            });

            const data = await res.json();
            setLoading(false)
            setDetails(data);
        }
        getData();
    }, [])

    const search = (event) => {
        const res = details.filter((item) => {
            return `${item.name}`
                .includes(event.target.value)
        })

        setDetails(res)
        setSearchPhrase(event.target.value)
        console.log(searchPhrase)
    }

  return (
    <div>
        <div className="search-container">
              <input type="text" className="search-input" value={searchPhrase} placeholder="Enter Keywords" onChange={search} />
        </div>
        
        <div className="details-container">
            {details.map((item, index) => (
                <div className="row-container" key={index}>
                    <img src={item.links.patch.small} alt="" />
                    <div className="info-container">
                        <div className='info-header'>
                            <h5>Flight Number{item.flight_number}: </h5>
                            <h5>{item.name}</h5>
                            <h5>({item.date_local})</h5>
                        </div>
                        
                        <p>Details: {item.details}</p>
                    </div>
                </div>
            ))}
        </div>
        <div>
              {loading ? (
                <div className="Loading"></div>
              ) : (
                      <div style={{ fontSize: "24px", marginBottom: "50px"}}>--- No more data can be fetch ---</div>
            )}
        </div>
    </div>
  )
}

export default Body